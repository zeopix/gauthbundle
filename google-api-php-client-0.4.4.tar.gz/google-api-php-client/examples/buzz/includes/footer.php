</div>
<div class="footer">
	<center>
		<a href="http://code.google.com/p/google-api-php-client">Google API PHP Client Library</a>
	</center>
</div>
</body>
</html>